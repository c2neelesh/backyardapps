//
//  MyInviteCell.swift
//  thRED
//
//  Created by Neelesh Shah on 1/17/17.
//  Copyright © 2017 C2 Consulting, Inc. All rights reserved.
//

import UIKit

class MyInviteCell: UICollectionViewCell {
    
    @IBOutlet weak var eventSongImageView: UIImageView!

}
